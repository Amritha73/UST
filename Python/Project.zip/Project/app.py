
import pymongo
from flask import Flask, redirect, render_template, request, session
from flask_pymongo import PyMongo

app = Flask(__name__,template_folder='templates')

#mongodb://localhost:27017
app.config['MONGO_URI'] = 'mongodb://localhost:27017/BringMyFoodCollection'
mongo = PyMongo(app)
holder = list()

@app.route('/')
def login_page():
    for i in collection.find():
            holder.append(i)
            print(holder)
    return render_template("login.html")



@app.route('/book',methods=['GET','POST'])
def book():
    
    if request.method=="POST":
        
        Table=request.form['Table_Num']
        print(Table)
        Food=request.form['food']
        print(Food)
        fname=request.form['fname']
        input_dict={"Table_Num":Table,"fname":fname,"food":Food,"Status":"Booked",'DeliveryStatus':'Out for Delivery',"Rating":"Not yet rated"}
        if collection1.count_documents({'Table_Num':  Table}, limit=1) != 0:
            alldoc=collection1.find()
            return render_template('home.html',alldoc=alldoc)
        else:
            collection1.insert_one(input_dict)
            alldoc=collection1.find()
            return render_template('home.html',alldoc=alldoc)
    return render_template("create.html")

@app.route('/dashboard')
def hello():
    alldoc=collection1.find()
    return render_template('home.html',alldoc=alldoc)

@app.route('/update/<string:Table_Num>')
def up(Table_Num):
    
    myquery = {"Table_Num":Table_Num}
    newvalues = {"$set":{"DeliveryStatus":"Delivered"}}
    collection1.update_one(myquery, newvalues)
    alldoc=collection1.find()
    return render_template('home.html',alldoc=alldoc)

@app.route('/Excellent/<string:Table_Num>')
def Excellent(Table_Num):
    myquery = {"Table_Num":Table_Num}
    newvalues = {"$set":{"Rating":"Excellent"}}
    collection1.update_one(myquery, newvalues)
    alldoc=collection1.find()
    return render_template('home.html',alldoc=alldoc)

@app.route('/Average/<string:Table_Num>')
def Average(Table_Num):
    myquery = {"Table_Num":Table_Num}
    newvalues = {"$set":{"Rating":"Average"}}
    collection1.update_one(myquery, newvalues)
    alldoc=collection1.find()
    return render_template('home.html',alldoc=alldoc)

@app.route('/Poor/<string:Table_Num>')
def poor(Table_Num):
    myquery = {"Table_Num":Table_Num}
    newvalues = {"$set":{"Rating":"Poor"}}
    collection1.update_one(myquery, newvalues)
    alldoc=collection1.find()
    return render_template('home.html',alldoc=alldoc)


@app.route('/delete/<string:Table_Num>') 
def delete(Table_Num):
    
    
    collection1.delete_one({"Table_Num":Table_Num})
    alldoc=collection1.find()
    return render_template('home.html',alldoc=alldoc)   
        
    

@app.route('/',methods=['GET','POST'])
def login():

    if request.method=='POST':
       
        username=request.form['username']
        password=request.form['password']
        
        filtered=[d for d in holder if condition(d,username, password)]
    if filtered:
        return redirect('/dashboard')
    else:
        print("Wrong Username or Password")
        return redirect('/')
        

@app.route('/register',methods=['GET','POST'])
def register():
    if request.method=="POST":
        first_name=request.form['fname']
        print(first_name)
        last_name=request.form['lname']
        print(last_name)
        user_name=request.form['username']
        print(user_name)
        password=request.form['password']
        print(password)
        input_dict={"first_name":first_name,"last_name":last_name,"username":user_name,"password":password}
        
        if collection.count_documents({'username':  user_name}, limit=1) != 0:
            
            return render_template('register.html')

        else:
            collection.insert_one(input_dict)
            return redirect("/")
    return render_template("register.html")


    
    
def condition(dict, username, password):
    return dict['username'] == username and dict['password'] == password


if __name__=='__main__':
    client = pymongo.MongoClient("mongodb://localhost:27017")
    print(client)
    db=client['BringMyFoodDB']
    collection=db['BringMyFoodCollection']
    db1=client['Food_Items_DB']
    collection1=db1['Food_Items_Collection']
    for i in collection.find():
        holder.append(i)
    app.run(debug=True,port=8000)
